import React from 'react'

import Cards from './Cards/Cards';
import Heading from './OfficeSource/Heading'
function App() {
  return (
    <>
    <Heading />
    <Cards />
    </>
  );
}

export default App;
